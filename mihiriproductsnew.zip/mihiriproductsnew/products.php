<!DOCTYPE html>
<?php
if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
} else {
    $id = null;
}
?>
<?php include('includes/config.php'); ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <title><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?></title>
    <?php  } ?>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <link href="img/company-icon/<?php echo htmlentities($row['icon']);?>" rel="icon">
    <?php  } ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
        <div class="modal fade" id="searchModal" tabindex="-1">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content" style="background: rgba(29, 29, 39, 0.7);">
                    <div class="modal-header border-0">
                        <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center justify-content-center">
                        <div class="input-group" style="max-width: 600px;">
                            <input type="text" class="form-control bg-transparent border-light p-3" placeholder="Type search keyword">
                            <button class="btn btn-light px-4"><i class="bi bi-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <div class="container-xxl bg-white p-0">
        <?php include('includes/header.php');?>

            <div class="container-xxl py-5 bg-primary hero-header mb-5">
                <div class="container my-5 py-5 px-lg-5">
                    <div class="row g-5 py-5">
                        <div class="col-12 text-center">
                            <?php $query = mysqli_query($con, "SELECT * FROM category WHERE id='$id'");
                                while($row = mysqli_fetch_assoc($query)) { ?>
                            <h1 class="text-white section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">&#128395; <?php echo  $row['categoryName']; ?></h1><?php } ?>
                            <div class="row g-4">
                            <?php $query = mysqli_query($con, "SELECT * FROM products WHERE category='$id'"); while($row = mysqli_fetch_assoc($query)) { ?>
                                <div class="col-sm-6 col-md-4 col-lg-3">
                                    <div class="product-card position-relative overflow-hidden rounded shadow-sm" style="transition: transform 0.3s;">
                                      
                                        <img src="img/products/<?php echo $row['id']; ?>/<?php echo $row['productImage']; ?>" 
                                           class="w-100 h-100 object-fit-cover product-image" 
                                           alt="<?php echo $row['productName']; ?>" 
                                           style="min-height: 320px; max-height: 320px; transition: transform 0.5s ease;">
                                        <div class="product-info position-absolute bottom-0 start-0 end-0 text-white p-3"
                                           style="background: rgba(0, 0, 0, 0.2); backdrop-filter: blur(2px);  -webkit-backdrop-filter: blur(10px); border-top: 1px solid rgba(255, 255, 255, 0.1);">
                                            <h5 style="color: white" class="mb-1"><?php echo $row['productName']; ?></h5>
                                            <a href="products_view.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-light">Explore more</a>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('includes/footer.php');?>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top pt-2"><i class="bi bi-arrow-up"></i></a>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="js/main.js"></script>
    <script type='text/javascript' src='http://code.jquery.com/jquery-1.4.4.min.js'></script>
    <script type='text/javascript'>
        $(function(){
        $('body').bind('contextmenu', function(e){
        return false;
        }); });
    </script>
</body>
</html>