<!DOCTYPE html>
<?php include('includes/config.php'); 
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $telnumber=$_POST['telnumber'];
    $district=$_POST['district'];
    $address=$_POST['address'];
    $message=$_POST['message'];
    $cimage=$_FILES["cimage"]["name"];
    $status=$_POST['status'];
$query=mysqli_query($con,"select max(id) as id from contacts");
    $result=mysqli_fetch_array($query);
     $id=$result['id']+1;
    $dir="img/contact/$id";
if(!is_dir($dir)){
        mkdir("img/contact/".$id);
    }
    move_uploaded_file($_FILES["cimage"]["tmp_name"],"img/contact/$id/".$_FILES["cimage"]["name"]);
$sql=mysqli_query($con,"insert into contacts(name,email,telnumber,district,address,message,cimage,status) values('$name','$email','$telnumber','$district','$address','$message','$cimage','$status')");
$_SESSION['msg']="Send Message Successfully !!";
}
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <title><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?></title>
    <?php  } ?>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <link href="img/company-icon/<?php echo htmlentities($row['icon']);?>" rel="icon">
    <?php  } ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"> 
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-xxl bg-white p-0">
        <?php include('includes/header.php');?>
            <div class="container-xxl py-5 bg-primary hero-header mb-5">
                <div class="container my-5 py-5 px-lg-5">
                    <div class="row g-5 py-5">
                        <div class="col-12 text-center">
                            <h1 class="text-white animated zoomIn">Contact Us</h1>
                            <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                            <div class="wow fadeInUp" data-wow-delay="0.3s">
                            <?php if(isset($_POST['submit'])){ ?>
                                <div class="alert alert-success">
                                    <button type="button" class="fa fa-check" style="color:green"></button>
                                    <strong>Well done!</strong> <?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
                                </div>
                                <?php } ?>
                                <?php if(isset($_GET['del'])) { ?>
                                <div class="alert alert-error">
                                    <button type="button" class="fa fa-close" style="color:red"></button>
                                    <strong>Oh snap!</strong>   <?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?>
                                </div>
                                <?php } ?>
                                <br />
                                <form method="post" enctype="multipart/form-data">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                                                <label for="name">Your Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="email" class="form-control" id="email" name="email" placeholder="Your Email">
                                                <label for="email">Your Email</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <input type="number" class="form-control" id="telnumber" name="telnumber" placeholder="Your Telephone Number" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required>
                                                <label for="telnumber">Your Telephone Number</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating">
                                                <select id="district" name="district" class="form-control">
                                                    <option value="">Your District</option>
                                                    <option value="Ratnapura">Ratnapura</option>
                                                    <option value="Colombo">Colombo</option>
                                                    <option value="Gampaha">Gampaha</option>
                                                    <option value="Mahanuvara">Mahanuvara</option>
                                                    <option value="Matale">Matale</option>
                                                    <option value="Nuvara Eliya">Nuvara Eliya</option>
                                                    <option value="Ampara">Ampara</option>
                                                    <option value="Madakalapuva">Madakalapuva</option>
                                                    <option value="Polonnaruva">Polonnaruva</option>
                                                    <option value="Trincomalee">Trincomalee</option>
                                                    <option value="Anuradhapura">Anuradhapura</option>
                                                    <option value="Vavuniyava">Vavuniyava</option>
                                                    <option value="Mannarama">Mannarama</option>
                                                    <option value="Mulativ">Mulativ</option>
                                                    <option value="Jafna">Jafna</option>
                                                    <option value="Kilinochchi">Kilinochchi</option>
                                                    <option value="Kurunagala">Kurunagala</option>
                                                    <option value="Puttalama">Puttalama</option>
                                                    <option value="Galle">Galle</option>
                                                    <option value="Hambantota">Hambantota</option>
                                                    <option value="Matara">Matara</option>
                                                    <option value="Badulla">Badulla</option>
                                                    <option value="Monaragala">Monaragala</option>
                                                    <option value="Kagalla">Kegalla</option>
                                                    <option value="Kalutara">Kalutara</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <textarea class="form-control" placeholder="Your Address" id="address" name="address" required></textarea>
                                                <label for="address">Your Address</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <textarea class="form-control" placeholder="Leave a message here" id="message" name="message" style="height: 150px"></textarea>
                                                <label for="message">Message</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input type="file" name="cimage" id="cimage" value="" class="form-control">
                                                <label for="cimage">Image</label>
                                            </div>
                                        </div>
                                        <input type="hidden" name="status" id="status" value="UnRead" class="form-control" required>
                                        <div class="col-12">
                                            <button style="background-color: red" class="btn btn-primary rounded-pill px-4 me-3" type="submit" name="submit">Send Message</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <div class="modal fade" id="searchModal" tabindex="-1">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content" style="background: rgba(29, 29, 39, 0.7);">
                    <div class="modal-header border-0">
                        <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center justify-content-center">
                        <div class="input-group" style="max-width: 600px;">
                            <input type="text" class="form-control bg-transparent border-light p-3" placeholder="Type search keyword">
                            <button class="btn btn-light px-4"><i class="bi bi-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('includes/footer.php');?>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top pt-2"><i class="bi bi-arrow-up"></i></a>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="js/main.js"></script>
    <script type='text/javascript' src='http://code.jquery.com/jquery-1.4.4.min.js'></script>
    <script type='text/javascript'>
        $(function(){
        $('body').bind('contextmenu', function(e){
        return false;
        }); });
    </script>
</body>

</html>