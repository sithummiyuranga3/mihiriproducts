<div class="container-fluid pt-4 px-4">
    <div class="bg-secondary rounded-top p-4">
        <div class="row">
        <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
            <div class="col-12 col-sm-6 text-center text-sm-start">Copyright &copy; <script type="text/javascript">document.write(new Date().getFullYear());</script> <a href="#"><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?></a>, All Right Reserved. 
            </div><?php }  ?>
            <div class="col-12 col-sm-6 text-center text-sm-end">Designed By 
            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='17'"); while($row=mysqli_fetch_array($ret)) { ?>
                <a href="<?php echo htmlentities($row['details']);?>"><?php }  ?>
                <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='9'"); while($row=mysqli_fetch_array($ret)) { ?> <?php echo htmlentities($row['details']);?></a>
            </div><?php }  ?>
        </div>
    </div>
</div>