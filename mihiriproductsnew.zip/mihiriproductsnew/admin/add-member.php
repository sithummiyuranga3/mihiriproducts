<?php
session_start();
include('..//includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:login.php');
}
else{
date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'd-m-Y h:i:s A', time () );
}
if(isset($_GET['del']))
          {
                  mysqli_query($con,"delete from member where mid = '".$_GET['mid']."'");
                  $_SESSION['delmsg']="Member deleted !!";
          }
if(isset($_POST['submit']))
{
    $mfirstname=$_POST['mfirstname'];
    $msecondname=$_POST['msecondname'];
    $mfullname=$_POST['mfullname'];
    $maddress=$_POST['maddress'];
    $midnumber=$_POST['midnumber'];
    $mbirthday=$_POST['mbirthday'];
    $mtpnumber=$_POST['mtpnumber'];
    $memail=$_POST['memail'];
    $mposition=$_POST['mposition'];
    $image=$_FILES["image"]["name"];
$query=mysqli_query($con,"select max(mid) as mid from member");
    $result=mysqli_fetch_array($query);
     $mid=$result['mid']+1;
    $dir="../img/company-members-gallery/$mid";
if(!is_dir($dir)){
        mkdir("../img/company-members-gallery/".$mid);
    }
    move_uploaded_file($_FILES["image"]["tmp_name"],"../img/company-members-gallery/$mid/".$_FILES["image"]["name"]);
$sql=mysqli_query($con,"insert into member(mfirstname,msecondname,mfullname,maddress,midnumber,mbirthday,mtpnumber,memail,mposition,mpic) values('$mfirstname','$msecondname','$mfullname','$maddress','$midnumber','$mbirthday','$mtpnumber','$memail','$mposition','$image')");
$_SESSION['msg']="Successfully !!";
}
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <title><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?></title>
    <?php  } ?>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <link href="../img/company-icon/<?php echo htmlentities($row['icon']);?>" rel="icon">
    <?php  } ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <?php include('includes/sidebar.php');?> 
        <div class="content">
            <?php include('includes/header.php');?>
            <div class="container-fluid pt-4 px-4">
                <div class="bg-secondary text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
                        <h6 class="mb-0"><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?> Member</h6>
                    <?php  } ?>
                        <a href="">Show All</a>
                    </div>
                     <?php if(isset($_POST['submit'])){ ?>
                                    <div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong>Well done!</strong> <?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
                                    </div>
                                    <?php } ?>
                                    <?php if(isset($_GET['del'])) { ?>
                                    <div class="alert alert-error">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <strong>Oh snap!</strong>   <?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?>
                                    </div>
                                    <?php } ?>
                                    <br />
                    <div class="table-responsive">
                        <form name="insertproduct" method="post" enctype="multipart/form-data">
                        <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead> 
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">First Name</th>
                                    <th><input type="text" name="mfirstname" id="mfirstname" value="" placeholder="" class="span8 tip" required></th>
                                </tr>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Second Name</th>
                                    <th><input type="text" name="msecondname" id="msecondname" value="" placeholder="" class="span8 tip" required></th>
                                </tr>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Full Name</th>
                                    <th><input type="text" name="mfullname" id="mfullname" value="" placeholder="" class="span8 tip" required></th>
                                </tr>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Address</th>
                                    <th><input type="text" name="maddress" id="maddress" value="" placeholder="" class="span8 tip" required></th>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Id Number</th>
                                    <th><input type="text" name="midnumber" id="midnumber" value="" placeholder="" class="span8 tip" required></th>
                                </tr>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Birthday</th>
                                    <th><input type="text" name="mbirthday" id="mbirthday" value="" placeholder="" class="span8 tip" required></th>
                                </tr>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Phone Number</th>
                                    <th><input type="text" name="mtpnumber" id="mtpnumber" value="" placeholder="" class="span8 tip" required></th>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Email</th>
                                    <th><input type="text" name="memail" id="memail" value="" placeholder="" class="span8 tip" required></th>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Position</th>
                                    <th><select name="mposition" id="mposition" class="form-select form-select-sm mb-3" aria-label=".form-select-sm example" required>
                                        <option selected>Select Position</option>
                                        <option value="Chaiman">Chaiman (President)</option>
                                        <option value="Vice President">Vice President</option>
                                        <option value="Secretarty">Secretarty</option>
                                        <option value="Deputy Secretarty">Deputy Secretarty</option>
                                        <option value="Treasurer">Treasurer</option>
                                        <option value="Organizer">Organizer</option>
                                </tr>
                                <tr class="text-white">
                                    <th scope="col"><input class="form-check-input" type="checkbox"></th>
                                    <th scope="col">Profile Picture</th>
                                    <th><input name="image" id="image" class="form-control form-control-sm bg-dark" type="file" required>
                                    </th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <button type="submit" name="submit" class="btn btn-sm btn-primary">Submit</button>
                </form>
                </div>
            </div>
            <?php include('includes/footer.php');?>
        </div>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>