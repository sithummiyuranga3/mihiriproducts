<!DOCTYPE html>
<?php include('includes/config.php'); 
if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
} else {
    $id = null;
}
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <title><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?></title>
    <?php  } ?>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <link href="img/company-icon/<?php echo htmlentities($row['icon']);?>" rel="icon">
    <?php  } ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-xxl bg-white p-0">
        <?php include('includes/header.php');?>
            <div class="container-xxl py-5 bg-primary hero-header mb-5">
                <div class="container my-5 py-5 px-lg-5">
                    <div class="row g-5 py-5">
                        <div class="col-lg-6 text-center text-lg-start">
                            <?php $query = mysqli_query($con, "SELECT * FROM products WHERE id='$id'"); while($row = mysqli_fetch_assoc($query)) { ?>
                            <h1 class="text-white mb-4 animated zoomIn"><b> <?php echo  $row['productName']; ?></b></h1>
                        <div class="text-white mb-4 animated zoomIn" id="clockbox" style=""></div>
                            <p class="text-white mb-4 animated zoomIn"><b>Description</b><br> <?php echo html_entity_decode($row['productDescription']); ?></p>
                            <p class="text-white pb-3 animated zoomIn"><b> Ingredients</b><br>Available Packagine Sizes:<br><?php echo html_entity_decode($row['weight']); ?></p>
                        </div>
                        <div class="col-lg-6 text-center text-lg-start">
                            <img class="img-fluid wow zoomIn" data-wow-delay="0.5s" src="img/products/<?php echo htmlentities($row['id']);?>/<?php echo htmlentities($row['productImage']);?>" alt="No Picture">
                            <?php  } ?>
                        </div>
                    </div>
                </div>
            </div>
        <div class="modal fade" id="searchModal" tabindex="-1">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content" style="background: rgba(29, 29, 39, 0.7);">
                    <div class="modal-header border-0">
                        <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center justify-content-center">
                        <div class="input-group" style="max-width: 600px;">
                            <input type="text" class="form-control bg-transparent border-light p-3" placeholder="Type search keyword">
                            <button class="btn btn-light px-4"><i class="bi bi-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container pb-5">
        </div>
        <?php include('includes/footer.php');?>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top pt-2"><i class="bi bi-arrow-up"></i></a>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>