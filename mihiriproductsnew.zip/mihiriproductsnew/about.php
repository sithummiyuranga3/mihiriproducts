<!DOCTYPE html>
<?php include('includes/config.php'); ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <title><?php echo htmlentities($row['firstname']);?> <?php echo htmlentities($row['secondname']);?></title>
    <?php  } ?>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
    <link href="img/company-icon/<?php echo htmlentities($row['icon']);?>" rel="icon">
    <?php  } ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-xxl bg-white p-0">
        <?php include('includes/header.php');?>
            <div class="container-xxl py-5 bg-primary hero-header mb-5">
                <div class="container my-5 py-5 px-lg-5">
                    <div class="row g-5 py-5">
                        <div class="col-12 text-center">
                            <h1 class="text-white animated zoomIn">Our Profile</h1>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="searchModal" tabindex="-1">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content" style="background: rgba(29, 29, 39, 0.7);">
                    <div class="modal-header border-0">
                        <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center justify-content-center">
                        <div class="input-group" style="max-width: 600px;">
                            <input type="text" class="form-control bg-transparent border-light p-3" placeholder="Type search keyword">
                            <button class="btn btn-light px-4"><i class="bi bi-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-xxl py-5">
            <div class="container px-lg-5">
                
                <div class="row g-4">
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item">
                            <div class="d-flex">
                                <div class="flex-shrink-0 d-flex flex-column align-items-center mt-4 pt-5" style="width: 75px;">
                                    <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='7'"); while($row=mysqli_fetch_array($ret)) { ?>
                                    <a class="btn btn-square text-primary bg-white my-1" href="<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                    <?php } ?>
                                    <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='8'"); while($row=mysqli_fetch_array($ret)) { ?>
                                    <a class="btn btn-square text-primary bg-white my-1" href="<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-youtube"></i></a>
                                    <?php } ?>
                                    <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='5'"); while($row=mysqli_fetch_array($ret)) { ?>
                                    <a class="btn btn-square text-primary bg-white my-1" href="ttps://api.whatsapp.com/send?phone=<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                    <?php } ?>
                                </div>
                                <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
                                <img class="img-fluid rounded w-100" src="company-gallery/CEO-picture1/<?php echo htmlentities($row['ceopic1']);?>" alt="">
                                <?php  } ?>
                            </div>
                            <div class="px-4 py-3">
                                <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='3'"); while($row=mysqli_fetch_array($ret)) { ?>
                                <h5 class="fw-bold m-0"><?php echo htmlentities($row['details']);?></h5>
                                <?php  } ?>
                                <small>Company CEO</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item">
                            <div class="d-flex">
                            </div>
                            <div class="px-4 py-3">
                                <h5 class="fw-bold m-0"></h5>
                                <small></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="section-title position-relative mb-4 pb-2">
                            <h6 class="position-relative text-primary ps-4">About Us</h6>
                            <h2 class="mt-2">The best SEO solution with 10 years of experience</h2>
                        </div>
                        <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum et tempor sit. Aliqu diam amet diam et eos labore. Clita erat ipsum et lorem et sit, sed stet no labore lorem sit. Sanctus clita duo justo et tempor eirmod magna dolore erat amet</p>
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <h6 class="mb-3"><i class="fa fa-check text-primary me-2"></i>Award Winning</h6>
                                <h6 class="mb-0"><i class="fa fa-check text-primary me-2"></i>Professional Staff</h6>
                            </div>
                            <div class="col-sm-6">
                                <h6 class="mb-3"><i class="fa fa-check text-primary me-2"></i>24/7 Support</h6>
                                <h6 class="mb-0"><i class="fa fa-check text-primary me-2"></i>Fair Prices</h6>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mt-4">
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='5'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <a class="btn btn-primary rounded-pill px-4 me-3" href="<?php echo htmlentities($row['details']);?>">Read More</a>
                            <a class="btn btn-outline-details btn-square me-3" href="<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-primary btn-square me-3" href="<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-primary btn-square me-3" href="https://api.whatsapp.com/send?phone=<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-whatsapp"></i></a>
                            <?php  } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('includes/footer.php');?>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top pt-2"><i class="bi bi-arrow-up"></i></a>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="js/main.js"></script>
    <script type='text/javascript' src='http://code.jquery.com/jquery-1.4.4.min.js'></script>
    <script type='text/javascript'>
        $(function(){
        $('body').bind('contextmenu', function(e){
        return false;
        }); });
    </script>
</body>

</html>