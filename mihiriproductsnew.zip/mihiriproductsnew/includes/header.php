<link rel="stylesheet" href="css/style-new.css" />
<!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-grow text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
        <div class="container-xxl position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
                <a href="index.php" class="navbar-brand p-0">
                    <?php $ret = mysqli_query($con,"SELECT * FROM company WHERE id='1'"); while($row=mysqli_fetch_array($ret)) { ?>
                    <h1 class="m-0"><img src="img/company-icon/<?php echo htmlentities($row['icon']);?>"> <?php echo htmlentities($row['firstname']);?> <span class="fs-5"><?php echo htmlentities($row['secondname']);?></span></h1><?php  } ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a href="index.php" class="nav-item nav-link ">Home</a>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="productDropdown" data-bs-toggle="dropdown" aria-expanded="false"> Products</a>
                            <ul class="dropdown-menu p-3" aria-labelledby="productDropdown" style="">
                                <div class="row" style="color: black">
                                  <?php $ret = mysqli_query($con,"SELECT * FROM category"); while($row=mysqli_fetch_array($ret)) { ?>
                                  <a class="btn btn-link" href="products.php?id=<?php echo $row['id']; ?>"><?php echo htmlentities($row['categoryName']);?></a>
                                  <?php  } ?>
                                </div>
                            </ul>
                        </li>
                        <a href="gallery.php" class="nav-item nav-link">Gallery</a>
                        <a href="project.php" class="nav-item nav-link" hidden>Project</a>
                        <div class="nav-item dropdown" hidden>
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu m-0">
                                <a href="team.php" class="dropdown-item">Our Team</a>
                                <a href="testimonial.php" class="dropdown-item">Testimonial</a>
                                <a href="404.php" class="dropdown-item">404 Page</a>
                            </div>
                        </div>
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                    </div>
                    <butaton type="button" class="btn text-secondary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="fa fa-search"></i></butaton>
                    
                    <a href="" class="btn btn-secondary text-light rounded-pill py-2 px-4 ms-3">Facebook</a>
                </div>
            </nav>
        </div>
        <div class="cookie_box" id="cookie_box" hidden>
            <img src="img/cookies.png">
            <h3>Cookie Policy</h3>
            <p> <a href="#">Learn more</a></p>
            <button id="activeBtn">Accept</button>
        </div>
<style>
#chat-toggle {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background-color: #007bff;
  color: white;
  font-size: 30px;
  border: none;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
  cursor: pointer;
  z-index: 9999;
}
</style>

<button id="chat-toggle" title="Chat">
  💬
</button>
<style>
#chat-box {
  position: fixed;
  bottom: 90px;
  right: 20px;
  width: 300px;
  max-height: 400px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
  overflow: hidden;
  display: none;
  flex-direction: column;
  z-index: 9998;
  font-family: sans-serif;
}

#chat-header {
  background: #007bff;
  color: white;
  padding: 10px;
  font-weight: bold;
}

#chat-body {
  flex: 1;
  padding: 10px;
  font-size: 14px;
  background: #f8f9fa;
  overflow-y: auto;
}

#chat-input-area {
  display: flex;
  padding: 10px;
  background: #f1f1f1;
}

#chat-input {
  flex: 1;
  padding: 5px;
  font-size: 14px;
}

#send-button {
  background: #007bff;
  color: white;
  border: none;
  padding: 6px 12px;
  margin-left: 5px;
  cursor: pointer;
}
.dropdown-menu {
    border: none;
    box-shadow: 0px 5px 15px rgba(0,0,0,0.2);
}
.dropdown-menu a:hover {
    background-color: #f8f9fa;
    color: #d33c2d;
}
</style>

<div id="chat-box">
  <div id="chat-header">💬 Mihiri Assistant</div>
  <div id="chat-body">
    <div><strong>Bot:</strong> හෙලෝ! මොනවද උදව් කරන්නෙ?</div>
  </div>
  <div id="chat-input-area">
    <input type="text" id="chat-input" placeholder="Type your message..." />
    <button id="send-button">Send</button>
  </div>
</div>

<!-- 🟢 Script -->
<script>
const chatToggle = document.getElementById('chat-toggle');
const chatBox = document.getElementById('chat-box');
const chatInput = document.getElementById('chat-input');
const sendButton = document.getElementById('send-button');
const chatBody = document.getElementById('chat-body');

// Toggle chat box
chatToggle.addEventListener('click', () => {
  chatBox.style.display = chatBox.style.display === 'none' ? 'flex' : 'none';
});

// Send message
sendButton.addEventListener('click', () => {
  const message = chatInput.value.trim();
  if (message !== '') {
    chatBody.innerHTML += `<div><strong>You:</strong> ${message}</div>`;
    chatInput.value = '';
    chatBody.scrollTop = chatBody.scrollHeight;

    // Bot reply (simple)
    setTimeout(() => {
      chatBody.innerHTML += `<div><strong>Bot:</strong> කරුණාකර අපට ඇමතුමක් කරන්න: 077-xxxxxxx</div>`;
      chatBody.scrollTop = chatBody.scrollHeight;
    }, 800);
  }
});
</script>

<script src="js/script.js"></script>