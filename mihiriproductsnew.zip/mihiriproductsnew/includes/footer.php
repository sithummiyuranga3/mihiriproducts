
<!-- Footer Start -->
        <div class="container-fluid bg-primary text-light footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5 px-lg-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-3">
                        <h5 class="text-white mb-4">Get In Touch</h5>
                        <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='6'"); while($row=mysqli_fetch_array($ret)) { ?>
                        <p><i class="fa fa-map-marker-alt me-3"></i><?php echo htmlentities($row['details']);?></p><?php  } ?>
                        <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='4'"); while($row=mysqli_fetch_array($ret)) { ?>
                        <p><i class="fa fa-phone-alt me-3"></i><a href="tel:+94<?php echo htmlentities($row['details']);?>" style="color: red"><?php echo htmlentities($row['details']);?><?php  } ?></a> || 
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='5'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <a href="tel:+94<?php echo htmlentities($row['details']);?>" style="color: red"><?php echo htmlentities($row['details']);?></p></a><?php  } ?>
                        <p><i class="fa fa-envelope me-3"></i>
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='2'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <?php echo htmlentities($row['details']);?></p><?php  } ?>
                        <div class="d-flex pt-2">
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='7'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <a class="btn btn-outline-light btn-social" href="<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-facebook"></i></a><?php  } ?>
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='8'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <a class="btn btn-outline-light btn-social" href="<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-youtube"></i></a><?php  } ?>
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='5'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <a class="btn btn-outline-light btn-social" href="https://api.whatsapp.com/send?phone=<?php echo htmlentities($row['details']);?>" target="_blank"><i class="fab fa-whatsapp"></i></a><?php  } ?>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h5 class="text-white mb-4">Popular Link</h5>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contact.php">Contact Us</a>
                        <a class="btn btn-link" type="button" class="btn text-secondary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal1">Privacy Policy</a>
                        <a class="btn btn-link" type="button" class="btn text-secondary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal2">Terms & Condition</a>
                        <a class="btn btn-link" type="button" class="btn text-secondary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal3">Career</a>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h5 class="text-white mb-4">Company Gallery</h5>
                        <div class="row g-2">
                            <?php $query=mysqli_query($con,"select * from gallery limit 6"); while($row=mysqli_fetch_array($query)) { ?>   
                            <div class="col-4">
                                <img src="img/gallery/<?php echo htmlentities($row['gid']);?>/<?php echo htmlentities($row['picname']);?>" class="img-fluid" alt="Image">
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h5 class="text-white mb-4">Newsletter</h5>
                        <p>Lorem ipsum dolor sit amet elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulpu</p>
                        <div class="position-relative w-100 mt-3">
                            <input class="form-control border-0 rounded-pill w-100 ps-4 pe-5" type="text" placeholder="Your Email" style="height: 48px;">
                            <button type="button" class="btn shadow-none position-absolute top-0 end-0 mt-1 me-2"><i class="fa fa-paper-plane text-primary fs-4"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container px-lg-5">
                <div class="copyright">
                    <div class="row">
                        <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='1'"); while($row=mysqli_fetch_array($ret)) { ?>
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            Copyright &copy; <span id="year"></span> <a class="border-bottom" href="#"><?php echo htmlentities($row['details']);?></a><?php  } ?>
                        <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='16'"); while($row=mysqli_fetch_array($ret)) { ?>
                            . <br>All Right Reserved. Designed By <a class="border-bottom" href="<?php echo htmlentities($row['details']);?>"><?php  } ?>
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='9'"); while($row=mysqli_fetch_array($ret)) { ?>
                                <?php echo htmlentities($row['details']);?></a><?php  } ?>.
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->
        <!-- Full Screen Search Start -->
                <div class="modal fade" id="searchModal1" tabindex="-1">
                    <div class="modal-dialog modal-fullscreen">
                        <div class="modal-content" style="background: rgba(29, 29, 39, 0.7);">
                            <div class="modal-header border-0">
                                <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <?php $ret = mysqli_query($con,"SELECT * FROM website WHERE wid='10'"); while($row=mysqli_fetch_array($ret)) { ?>
                            <div class="modal-body d-flex align-items-center justify-content-center">
                                <div class="input-group" style="max-width: 600px;">
                                    <h2 class="mb-4" style="color: white;"><?php echo htmlentities($row['details']);?></h2>
                                <div class="row g-3">
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                      document.getElementById("year").textContent = new Date().getFullYear();
                    </script>
                </div>
        <!-- Full Screen Search End -->
        <?php  } ?>