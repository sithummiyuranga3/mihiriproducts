-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2025 at 03:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mihiriproductsnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationdate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`, `regdate`, `updationdate`) VALUES
(1, 'admin', 'a5a01195b62ec3932464c27c412ccab1', 'sithummiyuranga3@gmail.com', '2023-04-17 03:46:16', '06-08-2025 07:06:46 AM');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) NOT NULL,
  `categoryDescription` longtext NOT NULL,
  `categorypic` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `categorypic`, `creationDate`, `updationDate`) VALUES
(1, 'Spaices', 'Miyuranga', 'Spices.png', '2025-08-05 17:13:04', NULL),
(2, 'Special Spices Mixtures', 'Miyuranga', 'Special-Spices.png', '2025-08-05 17:13:36', NULL),
(3, 'Soya', 'Miyuranga', 'Soya.png', '2025-08-05 17:13:53', NULL),
(4, 'flour', 'Miyuranga', 'Flour.png', '2025-08-05 17:14:13', NULL),
(5, 'Noodles', 'Miyuranga', 'Noodles.png', '2025-08-05 17:14:28', NULL),
(6, 'Beverage', 'Miyuranga', 'Beverage.png', '2025-08-05 17:14:43', NULL),
(7, 'Appetizers', 'Miyuranga', 'Appetizers.png', '2025-08-05 17:14:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `companyemail` varchar(255) NOT NULL,
  `companyfb` varchar(255) NOT NULL,
  `createdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationdate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `firstname`, `secondname`, `icon`, `companyemail`,`companyfb`, `createdate`, `updationdate`) VALUES
(1, 'Mihiri', 'Products', '10.png', 'sithummiyuranga3@gmail.com','sdaesdada', '2023-04-16 22:16:16', '2023-04-17 03:46:16');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telnumber` bigint(11) NOT NULL,
  `district` varchar(150) NOT NULL,
  `address` varchar(150) NOT NULL,
  `message` longtext NOT NULL,
  `cimage` longtext NOT NULL,
  `status` varchar(150) NOT NULL,
  `messagingdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gid` int(11) NOT NULL,
  `picname` varchar(255) NOT NULL,
  `createdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationdate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `mid` int(11) NOT NULL,
  `mfirstname` varchar(120) DEFAULT NULL,
  `msecondname` varchar(150) DEFAULT NULL,
  `mfullname` varchar(150) DEFAULT NULL,
  `maddress` varchar(150) DEFAULT NULL,
  `midnumber` varchar(150) DEFAULT NULL,
  `mbirthday` varchar(150) DEFAULT NULL,
  `mtpnumber` int(11) DEFAULT NULL,
  `mwnumber` int(11) NOT NULL,
  `memail` varchar(150) DEFAULT NULL,
  `mfblink` text NOT NULL,
  `mposition` varchar(150) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `mpic` text NOT NULL,
  `mregdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productDescription` longtext NOT NULL,
  `productImage` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

CREATE TABLE `website` (
  `wid` int(11) NOT NULL,
  `namec` varchar(120) NOT NULL,
  `name` varchar(150) NOT NULL,
  `details` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `website`
--

INSERT INTO `website` (`wid`, `namec`, `name`, `details`) VALUES
(1, 'companyname', 'Company Name', 'Mihiri Products'),
(2, 'companyemail', 'Company Email', 'mihiriproducts@gmail.com'),
(3, 'ceoname', 'CEO Name', 'Sithum Miyuranga'),
(4, 'contactnumber', 'Contact Number', '0702024997'),
(5, 'wnumber', 'Whatsapp Number', '0702024997'),
(6, 'address', 'Address', 'Hiriliyadda'),
(7, 'fblink', 'Facebook Link', 'aaaaaaaaaaaaaaaaaaa'),
(8, 'ytlink', 'Youtube Link', 'faef'),
(9, 'creatorname', 'Designer Name', 'Sithum Miyuranga'),
(10, 'privacy', 'Privacy', 'dscfsdcsdcfse'),
(11, 'teams', 'Teams', 'dvsvs'),
(12, 'career', 'Career', 'csdf'),
(13, 'cookies', 'Cookies', 'cookies'),
(14, 'companyshortdescription', 'Company Short Description', '<p style=\"font-family: cursive; font-size: 30px;\">Mihiri Products</p><p style=\"font-size: 20px;\">~Name of the good taste~</p>'),
(15, 'companylongdescription', 'Company Long Description', 'Variety is the spice of life, they say. True to this saying, we have curated a wide array of Ceylon spices and food products, affording our consumers in Sri Lanka and overseas the chance to experience a tasty meal with a distinctive flavour associated with Sri Lanka.\r\nAt the heart of every Sri Lankan kitchen lies a deep-rooted tradition of using rich, aromatic Ceylon spices. These spices are more than just ingredients; they are a celebration of culture, history, and flavour. Known for their purity and premium quality, Ceylon Spice Exports have gained global recognition, offering health-conscious and flavour-savvy consumers a trusted source for culinary excellence.\r\nAs a brand deeply committed to delivering quality, Mihiri Products ensures that every spice product reflects the authenticity of Sri Lanka’s heritage. Our dedication to ethical sourcing and high production standards helps us meet the expectations of both local and international markets, establishing us as a reliable name in Ceylon Spice Exports.\r\nOur team continuously monitors farming practices, hygiene standards, and packaging innovations to maintain the integrity of our offerings. Whether you\'re a home cook or a professional chef, Mihiri Products brings you the true essence of Sri Lankan spices – naturally grown, carefully processed, and packed with flavour.Explore our product range and taste the legacy of Ceylon Spices, proudly delivered by Mihiri Products.'),
(16, 'ceofblink', 'CEO Facebook Link', 'aaaaaaaaaaaaaaaaaa'),
(17, 'designerfblink', 'Designer Facebook Link', 'aaaaaaaaaaaaaaaaaaaaaaaaaaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `website`
--
ALTER TABLE `website`
  ADD PRIMARY KEY (`wid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `website`
--
ALTER TABLE `website`
  MODIFY `wid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
